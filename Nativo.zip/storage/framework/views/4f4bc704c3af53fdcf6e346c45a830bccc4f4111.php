<?php $__env->startSection('content'); ?>


<h1 class="h3 mb-2 text-gray-800">Editar Nivel</h1>
                   

                    <!-- Content Row -->
            <div class="row">

                <div class="col-xl-8 col-lg-7">
                   
                    <form method="post" action="<?php echo e(route('editNivel', ['nivel'=>$nivel->id])); ?>" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Nombre del Nivel </label>
                        <input class="form-control" name="nombre" value="<?php echo e($nivel->nombre); ?>">
                        
                      </div>
                     
                      
                      <button type="submit" class="btn btn-primary">Editar</button>
                    </form>
                   
                    

                </div>

                
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Nativo\resources\views/niveles/edit.blade.php ENDPATH**/ ?>