<?php $__env->startSection('content'); ?>


<h1 class="h3 mb-2 text-gray-800">Comunidad</h1>

                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-xl-12 col-lg-12">
                            <table class="table table-striped">
                              <thead>
                                <tr>
                                  <th scope="col">Imagen</th>
                                  <th scope="col">Titulo</th>   
                                  
                                  <th scope="col"></th>
                                  <th scope="col"><a title="Agregar novedad" href="/agregarNovedad"><i class="fas  fa-plus fa-lg"></i></a></th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $novedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $novedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>  
                                 <td><img width="80" src="/img/comunidad/<?php echo e($novedad->imagen); ?>" /></td>                               
                                  <td><?php echo e($novedad->titulo); ?></td>
                                
                                  <td><a title="Editar novedad" href="/showNovedad/<?php echo e($novedad->id); ?>"><i class="far fa-edit fa-lg"></i></a></td>
                                  <td><a title="Eliminar novedad" href="/borrarNovedad/<?php echo e($novedad->id); ?>"><i class="fas fa-trash-alt fa-lg"></i></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>


                            <div class="row"> 
                              <div class="col text-center">
                                <?php echo e($novedades->links()); ?>

                              </div>
                            </div>

                        </div>

                    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Nativo\resources\views/novedades/lista.blade.php ENDPATH**/ ?>