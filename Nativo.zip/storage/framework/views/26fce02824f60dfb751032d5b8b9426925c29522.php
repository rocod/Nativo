<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        

		
    </div>
    <div class="row  ">
    	<div class="d-flex justify-content-between align-items-center bgAzul pt-3 pb-3">
	    	<div class="fontMerri fSize20">CONOCÉ TODOS LOS CONTENIDOS POR <span class="celeste">EJES TEMÁTICOS</span></div>
	    	<div class="fontClimate fSize45"><span class="celeste"># </span>TEMAS</div>
	    </div>
	</div>

	<div class="container" id="detalleContenido">
			<div class="row azul" id="filtros">

				<div  class="col-12 pt-3 pb-5 ">
					<a onclick="history.back()">VOLVER A FILTROS </a>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<h2><?php echo e($contenido->titulo); ?></h2>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<p><?php echo e($contenido->resumen); ?></p>
				</div>
			</div>
			<?php if($contenido->id_formato==3 || $contenido->id_formato==4 || $contenido->id_formato==5 ): ?>
			<div class="row">
				<div class="col">
					<img width="100%" src="/img/portada/<?php echo e($contenido->portada); ?>" />
				</div>
			</div>
			<?php endif; ?>
			<div class="row mt-4 mb-4">
				<div class="col">
					 <?php switch($contenido->id_formato): 
					case (1): ?>
			        	<?php echo $contenido->texto; ?> 
			        <?php break; ?> 
			        <?php case (2): ?>
			        	<?php echo $contenido->texto; ?> 
			        <?php break; ?> 
			        <?php case (3): ?>
			        	<a class="btn btn-primary" target="_blank" href="/storage/uploads/<?php echo e($contenido->archivo); ?>" role="button">Descargar archivo</a>
			        <?php break; ?> 
			       <?php case (4): ?>
			        	<?php echo e($contenido->texto); ?> 
			        <?php break; ?>  
			        <?php case (5): ?>
			        	<a class="btn btn-primary" target="_blank" href="<?php echo e($contenido->link); ?> " role="button">Click aquí para acceder</a> 
			        <?php break; ?>
		        <?php endswitch; ?>
				</div>
			</div>
	</div>

</div><!-- fin container fluid-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.sitio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Nativo\resources\views/detalle_contenido.blade.php ENDPATH**/ ?>