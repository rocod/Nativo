<?php $__env->startSection('content'); ?>


<h1 class="h3 mb-2 text-gray-800">Crear nuevo contenido</h1>
                   

                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-xl-8 col-lg-7">
                           
                            <form method="post" enctype="multipart/form-data" action="<?php echo e(route('grabarContenido')); ?>" >
                                <?php echo csrf_field(); ?>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Título</label>
                                <input class="form-control" required name="titulo">
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Formato</label>
                                <select class="form-control" id="id_formato" required name="id_formato" required>
                                    <option value="">Seleccione</option>
                                    <?php $__currentLoopData = $formatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($formato->id); ?>"><?php echo e($formato->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </select>
                                
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Eje</label>
                                <select class="form-control" id="id_eje" name="id_eje" required>
                                    <option value="">Seleccione</option>
                                    <?php $__currentLoopData = $ejes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($eje->id); ?>"><?php echo e($eje->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Subcategoría</label>
                                <select class="form-control" name="id_subcategoria" id="id_subcategoria" required>
                                    <option value="">Seleccione</option>
                                    <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($subcategoria->id); ?>"><?php echo e($subcategoria->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Resumen</label>
                                <textarea class="form-control" required name="resumen"></textarea>
                              </div>
                              
                               <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Portada (imagen)</label>
                                <input type="file" required class="form-control" name="portada">
                              </div>

                              <div class="mb-3" id="contTexto">
                                <label for="exampleInputEmail1" class="form-label" id="titTexto">Texto</label>
                                <textarea id="comment" class="form-control" name="texto"></textarea>
                              </div>
                              <div class="mb-3" id="contLink">
                                <label for="exampleInputEmail1" class="form-label">Link</label>
                                <input class="form-control" name="link">
                              </div>
                               <div class="mb-3" id="contArchivo">
                                <label for="exampleInputEmail1" class="form-label">Archivo (pdf)</label>
                                <input type="file" class="form-control" name="archivo">
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Nivel</label>
                                <select class="form-control" name="id_nivel" required>
                                    <option value="">Seleccione</option>
                                    <?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($nivel->id); ?>"><?php echo e($nivel->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Autorx</label>
                                <select required class="form-control" name="id_autor" required>
                                    <option value="">Seleccione</option>
                                    <?php $__currentLoopData = $autorxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autorx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($autorx->id); ?>"><?php echo e($autorx->nombre); ?> <?php echo e($autorx->apellido); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Contribuyente</label>
                                <select class="form-control" name="id_contribuyente" >
                                     <option value="">Seleccione</option>
                                      <?php $__currentLoopData = $contribuyentxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribuyente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($contribuyente->id); ?>"><?php echo e($contribuyente->nombre); ?> <?php echo e($contribuyente->apellido); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Licencia</label>
                                <select class="form-control" required name="id_licencia" >
                                     <option value="">Seleccione</option>
                                      <?php $__currentLoopData = $licencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($licencia->id); ?>"><?php echo e($licencia->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Etiquetas</label>
                                    <div>
                                      <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php echo e($etiqueta->nombre); ?> <input type="checkbox" name="etiquetas[]" value="<?php echo e($etiqueta->id); ?>">  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </div>                        

                              </div>

                             
                              
                              <button type="submit" class="btn btn-primary">Agregar</button>
                            </form>
                           
                            

                        </div>

                        
                    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  
  $("#contTexto").hide();
  $("#contLink").hide();
  $("#contArchivo").hide();

  $('#id_formato').on('change', function(){

  $value=$(this).val();

  

  if($value==1){//audiovisual
   


    $("#contTexto").show();
   
    $("#titTexto").html('Pegar el código para embeber HTML </>  de Youtube u otra plataforma');

     $("#contLink").hide();
     $("#contArchivo").hide();

  }

  if($value==2){//podcst
   


    $("#contTexto").show();
   
    $("#titTexto").html('Pegar el código para embeber HTML </> de Spotify u otra plataforma');

     $("#contLink").hide();
     $("#contArchivo").hide();

  }



  if($value==3){//Archivo Pdf
   


    $("#contTexto").hide();
   
    //$("#titTexto").html('Pegar el código para embeber </>  de Youtube');

     $("#contLink").hide();
     $("#contArchivo").show();

  }

if($value==4){//texto
   


    $("#contTexto").show();
   
    $("#titTexto").html('Ingresá el texto completo');

     $("#contLink").hide();
     $("#contArchivo").hide();

  }

  if($value==5){//link web
   


    $("#contTexto").hide();
   
    $("#titTexto").html('Ingresá el texto completo');

     $("#contLink").show();
     $("#contArchivo").hide();

  }




});

$('#id_eje').on('change', function(){


  $value=$(this).val();
    $.ajax({
    type : 'get',
    url : '<?php echo e(URL::to('buscar_subcategoria')); ?>/'+$value,
    //data:{'localidad':$value},
    success:function(data){
    $('#id_subcategoria').html(data);
    }
    });

})
</script>
/*
 $("#comment").on("keypress", function(event){


    if($(this).val().length == 5){
         return false;
     }                
});*/

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Nativo\resources\views/contenidos/create.blade.php ENDPATH**/ ?>