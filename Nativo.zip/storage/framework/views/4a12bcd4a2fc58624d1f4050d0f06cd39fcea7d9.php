<?php $__env->startSection('content'); ?>


<h1 class="h3 mb-2 text-gray-800">Editar Contenido</h1>
                   

                    <!-- Content Row -->
            <div class="row">

                <div class="col-xl-8 col-lg-7">
                   
                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('editContenido', ['contenido'=>$contenido->id])); ?>" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Titulo del Contenido</label>
                        <input class="form-control" name="titulo" value="<?php echo e($contenido->titulo); ?>">
                        
                      </div>
                      <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Formato</label>
                                <select class="form-control" required name="id_formato" required>
                                    <option value="">Seleccione</option>
                                    <?php $__currentLoopData = $formatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option <?php if($contenido->id_formato== $formato->id): ?> selected <?php endif; ?> value="<?php echo e($formato->id); ?>"><?php echo e($formato->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                </select>
                                
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Subcategoría</label>
                                <select class="form-control" name="id_subcategoria" required>
                                    <option value="">Seleccione</option>
                                    <?php $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option  <?php if($contenido->id_subcategoria== $subcategoria->id): ?> selected <?php endif; ?> value="<?php echo e($subcategoria->id); ?>"><?php echo e($subcategoria->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Resumen</label>
                                <textarea class="form-control" required name="resumen"><?php echo e($contenido->resumen); ?></textarea>
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Texto</label>
                                <textarea class="form-control" name="texto"><?php echo e($contenido->texto); ?></textarea>
                              

                              </div>
                               <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Portada (imagen)</label>
                                <img width="100" src="/img/portada/<?php echo e($contenido->portada); ?>" />
                                <input type="file"  class="form-control" name="portada">
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Link</label>
                                <input class="form-control" value="<?php echo e($contenido->link); ?>" name="link">
                              </div>
                               <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Archivo (pdf) <?php if($contenido->archivo!=""): ?>  <a target="_blank" href="/storage/uploads/<?php echo e($contenido->archivo); ?>">Ver archivo</a> <?php endif; ?></label>

                                <input type="file" class="form-control" name="archivo">
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Nivel</label>
                                <select class="form-control" name="id_nivel" required>
                                    <option value="">Seleccione</option>
                                    <?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option  <?php if($contenido->id_nivel== $nivel->id): ?> selected <?php endif; ?> value="<?php echo e($subcategoria->id); ?>"><?php echo e($nivel->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Autorx</label>
                                <select required class="form-control" name="id_autor" required>
                                    <option value="">Seleccione</option>
                                    <?php $__currentLoopData = $autorxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autorx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option  <?php if($contenido->id_autor== $autorx->id): ?> selected <?php endif; ?> value="<?php echo e($autorx->id); ?>"><?php echo e($autorx->nombre); ?> <?php echo e($autorx->apellido); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Contribuyente</label>
                                <select class="form-control" name="id_contribuyente" >
                                     <option value="">Seleccione</option>
                                      <?php $__currentLoopData = $contribuyentxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribuyente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($contribuyente->id); ?>"><?php echo e($contribuyente->nombre); ?> <?php echo e($contribuyente->apellido); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Licencia</label>
                                <select class="form-control" required name="id_licencia" >
                                     <option value="">Seleccione</option>
                                      <?php $__currentLoopData = $licencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option  <?php if($contenido->id_licencia== $licencia->id): ?> selected <?php endif; ?> value="<?php echo e($licencia->id); ?>"><?php echo e($licencia->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </select>                                
                              </div>

                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Etiquetas</label>
                                    <div>
                                      <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php echo e($etiqueta->nombre); ?> 
                                      <input 
                                      <?php $__currentLoopData = $etiquetas_cont; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($eti->id_etiqueta== $etiqueta->id): ?>
                                        checked
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      type="checkbox" name="etiquetas[]" value="<?php echo e($etiqueta->id); ?>">  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                  
                                </div>                        

                              </div>
                     
                      
                      <button type="submit" class="btn btn-primary">Editar</button>
                    </form>
                   
                    

                </div>

                
            </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Nativo\resources\views/contenidos/edit.blade.php ENDPATH**/ ?>