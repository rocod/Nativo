<?php $__env->startSection('content'); ?>


<h1 class="h3 mb-2 text-gray-800">Contenidos</h1>

                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-xl-12 col-lg-12">
                            <table class="table table-striped">
                              <thead>
                                <tr>
                                  <th scope="col">Portada</th>
                                  <th scope="col">Nombre del Contenido</th>   
                                  <th scope="col">Tipo de contenido</th>
                                  <th scope="col">Subcategoría</th>
                                  <th scope="col"></th>
                                  <th scope="col"><a title="Agregar Contenidos" href="/agregarContenido"><i class="fas  fa-plus fa-lg"></i></a></th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $contenidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contenido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>  
                                 <td><img width="80" src="/img/portada/<?php echo e($contenido->portada); ?>" /></td>                               
                                  <td><?php echo e($contenido->titulo); ?></td>
                                  <td><?php echo e($contenido->formatoNombre); ?></td>
                                  <td><?php echo e($contenido->subcategoriaNombre); ?></td>
                                  <td><a title="Editar Contenido" href="/showContenido/<?php echo e($contenido->id); ?>"><i class="far fa-edit fa-lg"></i></a></td>
                                  <td><a title="Eliminar Contenido" href="/borrarContenido/<?php echo e($contenido->id); ?>"><i class="fas fa-trash-alt fa-lg"></i></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>


                            <div class="row"> 
                              <div class="col text-center">
                                <?php echo e($contenidos->links()); ?>

                              </div>
                            </div>

                        </div>

                    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Nativo\resources\views/contenidos/lista.blade.php ENDPATH**/ ?>