<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center">
        

		
    </div>
    <div class="row  ">
    	<div class="d-flex justify-content-between align-items-center bgAzul pt-3 pb-3 lqd-column" data-custom-animations="true"
						data-ca-options='{"triggerHandler":"inview", "animationTarget":"all-childs", "duration":"1200", "delay":"130", "easing":"easeOutQuint", "direction":"forward", "initValues":{"translateY":50, "opacity":0}, "animations":{"translateY":0, "opacity":1}}'>
	    	<div class=" fSize20">CONOCÉ TODOS LOS CONTENIDOS POR <span class="celeste">EJES TEMÁTICOS</span></div>
	    	<div class="fontClimate fSize45"><span class="celeste"># </span>TEMAS</div>
	    </div>
	</div>
	<div class="row">
		<nav class="navbar navbar-expand-lg p-2" id="filtrosMovilCont" >
              <div class="container-fluid">
               
                <div class="btn-verfiltros" type="button" data-bs-toggle="collapse" data-bs-target="#FiltrosMovil" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  Ver Filtros
                </div>
                <div class="collapse navbar-collapse" id="FiltrosMovil">
                  <ul class="navbar-nav me-auto mb-2 mb-lg-0 menu">
                   <form action="/ver_contenidos" method="get">

					<h2 class="itemFiltro pt-4">Ejes</h2>
					<select name="id_eje" id="id_eje" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $ejes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_eje']) && $_GET['id_eje']==$eje->id): ?> selected <?php endif; ?> value="<?php echo e($eje->id); ?>"><?php echo e($eje->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Subcategorías</h2>
					<select name="id_subcategoria" id="id_subcategoria" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Nivel</h2>
					<select name="id_nivel" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option  <?php if(isset($_GET['id_nivel']) && $_GET['id_nivel']==$nivel->id): ?> selected <?php endif; ?> value="<?php echo e($nivel->id); ?>"><?php echo e($nivel->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Formato</h2>
					<select name="id_formato" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $formatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_formato']) && $_GET['id_formato']==$formato->id): ?> selected <?php endif; ?> value="<?php echo e($formato->id); ?>"><?php echo e($formato->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Etiquetas</h2>
					<select name="id_etiqueta" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_etiqueta']) && $_GET['id_etiqueta']==$etiqueta->id): ?> selected <?php endif; ?> value="<?php echo e($etiqueta->id); ?>"><?php echo e($etiqueta->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Autorxs (apellido)</h2>
					<select name="id_autor" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $autorxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_autor']) && $_GET['id_autor']==$autor->id): ?> selected <?php endif; ?> value="<?php echo e($autor->id); ?>"><?php echo e($autor->nombre); ?> <?php echo e($autor->apellido); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Otros contribuyentes (apellido)</h2>
					<select name="id_contribuyente" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $contribuyentxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribuyente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_contribuyente']) && $_GET['id_contribuyente']==$contribuyente->id): ?> selected <?php endif; ?> value="<?php echo e($contribuyente->id); ?>"><?php echo e($contribuyente->nombre); ?> <?php echo e($contribuyente->apellido); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Licencia</h2>
					<select name="id_licencia" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $licencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_licencia']) && $_GET['id_licencia']==$licencia->id): ?> selected <?php endif; ?> value="<?php echo e($licencia->id); ?>"><?php echo e($licencia->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					 <button type="submit" class="btn btn-primary">Filtrar</button>
				</form>
                  </ul>
                </div>
              </div>
            </nav>
	</div>



	<div class="container">
			<div class="row azul" id="filtros">
				<div id="FiltrosWeb" class="col-3 bgCeleste px-5 pt-5 pb-5">
					<h3 class="filtros">FILTROS DE BÚSQUEDA</h3>
					<form action="/ver_contenidos" method="get">

					<h2 class="itemFiltro pt-4">Ejes</h2>
					<select name="id_eje" id="id_eje" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $ejes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_eje']) && $_GET['id_eje']==$eje->id): ?> selected <?php endif; ?> value="<?php echo e($eje->id); ?>"><?php echo e($eje->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Subcategorías</h2>
					<select name="id_subcategoria" id="id_subcategoria" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Nivel</h2>
					<select name="id_nivel" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option  <?php if(isset($_GET['id_nivel']) && $_GET['id_nivel']==$nivel->id): ?> selected <?php endif; ?> value="<?php echo e($nivel->id); ?>"><?php echo e($nivel->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Formato</h2>
					<select name="id_formato" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $formatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_formato']) && $_GET['id_formato']==$formato->id): ?> selected <?php endif; ?> value="<?php echo e($formato->id); ?>"><?php echo e($formato->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Etiquetas</h2>
					<select name="id_etiqueta" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_etiqueta']) && $_GET['id_etiqueta']==$etiqueta->id): ?> selected <?php endif; ?> value="<?php echo e($etiqueta->id); ?>"><?php echo e($etiqueta->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Autorxs (apellido)</h2>
					<select name="id_autor" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $autorxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_autor']) && $_GET['id_autor']==$autor->id): ?> selected <?php endif; ?> value="<?php echo e($autor->id); ?>"><?php echo e($autor->nombre); ?> <?php echo e($autor->apellido); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Otros contribuyentes (apellido)</h2>
					<select name="id_contribuyente" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $contribuyentxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribuyente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_contribuyente']) && $_GET['id_contribuyente']==$contribuyente->id): ?> selected <?php endif; ?> value="<?php echo e($contribuyente->id); ?>"><?php echo e($contribuyente->nombre); ?> <?php echo e($contribuyente->apellido); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<hr  />
					<h2 class="itemFiltro pt-2">Licencia</h2>
					<select name="id_licencia" class="form-select form-select-lg mb-3" aria-label="Large select example">
					<option value="">+</option>	
					<?php $__currentLoopData = $licencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				  
					  <option <?php if(isset($_GET['id_licencia']) && $_GET['id_licencia']==$licencia->id): ?> selected <?php endif; ?> value="<?php echo e($licencia->id); ?>"><?php echo e($licencia->nombre); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					 <button type="submit" class="btn btn-primary">Filtrar</button>
				</form>

				</div>
				<div id="vistaPrevia" class="col-lg-9 col-md-12 pt-5 pb-5 ">
					
					<?php $__currentLoopData = $contenidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contenido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="row p-3 ">						
						  <div class="row unaVista lqd-column" data-custom-animations="true"
						data-ca-options='{"triggerHandler":"inview", "animationTarget":"all-childs", "duration":"1200", "delay":"130", "easing":"easeOutQuint", "direction":"forward", "initValues":{"translateY":50, "opacity":0}, "animations":{"translateY":0, "opacity":1}}'>
						    <div class="col-md-3 justify-content-center pb-2" style="overflow: hidden;">
						      <img height="120" src="/img/portada/<?php echo e($contenido->portada); ?>"   alt="titulo de la noticia">
						    </div>
						    <div class="col-md-7 pb-3" >
						      <div class="card-body">
						        <h5 class="card-title"><?php echo e($contenido->titulo); ?></h5>
						        <p class="card-text"><?php echo e($contenido->resumen); ?></p>
						       
						      </div>
						    </div>
						    <div class="col-md-2 d-flex align-items-center justify-content-end">
						    	<a class="verMascon" href="/detalle_contenido/<?php echo e($contenido->id); ?>"><div class="verMas">ver más +</div></a>
						    </div>
						  </div>
					
					</div><!--fin una vista previa-->

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					<div class="row"> 
						<div class="col text-center">
							<?php echo e($contenidos->links()); ?>

						</div>
					</div>

				</div>
			</div>
	</div>

</div><!-- fin container fluid-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script type="text/javascript">


$('#id_eje').on('change', function(){


  $value=$(this).val();
    $.ajax({
    type : 'get',
    url : '<?php echo e(URL::to('buscar_subcategoria')); ?>/'+$value,
    //data:{'localidad':$value},
    success:function(data){
    $('#id_subcategoria').html(data);
    }
    });

})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sitio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Nativo\resources\views/contenidos.blade.php ENDPATH**/ ?>