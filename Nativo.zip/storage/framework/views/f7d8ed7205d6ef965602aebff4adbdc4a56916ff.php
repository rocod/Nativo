<?php echo e($slot); ?>

<?php /**PATH C:\xampp2\htdocs\PlatUnahur\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>