<?php $__env->startSection('content'); ?>


<h1 class="h3 mb-2 text-gray-800">Crear novedad para Comunidad</h1>
                   

                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-xl-8 col-lg-7">
                           
                            <form method="post" enctype="multipart/form-data" action="<?php echo e(route('grabarNovedad')); ?>" >
                                <?php echo csrf_field(); ?>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Título</label>
                                <input class="form-control" required name="titulo">
                              </div>
                             
                               <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Imagen</label>
                                <input type="file" required class="form-control" name="imagen">
                              </div>

                              <div class="mb-3" id="contTexto">
                                <label for="exampleInputEmail1" class="form-label" id="titTexto">Texto</label>
                                <textarea id="comment" class="form-control" name="texto"></textarea>
                              </div>
                            
                             
                              
                              <button type="submit" class="btn btn-primary">Agregar</button>
                            </form>
                           
                            

                        </div>

                        
                    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  
  

</script>
/*
 $("#comment").on("keypress", function(event){


    if($(this).val().length == 5){
         return false;
     }                
});*/

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\Nativo\resources\views/novedades/create.blade.php ENDPATH**/ ?>